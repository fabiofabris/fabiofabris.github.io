source ../../sourceMe

epochs=1

# base_folder="'/tmp/deep/kegg'"
# feature_type="'kegg_features.csv'"
# binary_feature="True"
base_model="'module'"
# 
# for fold in $(seq 0 9); do
#     echo python experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':${fold}, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"
#     python experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':${fold}, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"
# done
# 
# echo python experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':-1, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"
# python experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':-1, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"


base_folder="'/tmp/deep/gtex'"
feature_type="'base_expression_gtex_features.csv'"
binary_feature="False"
# for fold in $(seq 0 9); do
#     echo python experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':${fold}, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"
#     python3 experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':${fold}, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"
# done

# echo python experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':-1, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"
# python3 experiment.py "{'base_folder':${base_folder}, 'epochs':${epochs}, 'seed':0, 'fold':-1, 'binary_feature':${binary_feature}, 'base_model':${base_model}, 'feature_type':${feature_type}}"



epochs=150
base_model="'joined'"
base_in_folder="'/home/ff201/deep_exp/results_proj/'"
feature_types="['pathdip','gtex','ppi','go']"

# for fold in $(seq 0 9); do
#     echo python experiment.py "{'base_folder':${base_folder}, 'base_in_folder':${base_in_folder}, 'epochs':${epochs}, 'fold':${fold}, 'models_to_load':${feature_types}, 'base_model':${base_model}}"
#     python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'base_in_folder':${base_in_folder}, 'epochs':${epochs}, 'fold':${fold}, 'models_to_load':${feature_types}, 'base_model':${base_model}}"
# done

for i in `seq 1 30`; do
    base_folder="'/home/ff201/deep_exp/results_proj_2/go+pathdip+ppi+gtex_${i}/'"
    echo python experiment.py "{'seed':0, 'base_folder':${base_folder}, 'base_in_folder':${base_in_folder}, 'epochs':${epochs}, 'fold':-1, 'models_to_load':${feature_types}, 'base_model':${base_model}}"
    python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'base_in_folder':${base_in_folder}, 'epochs':${epochs}, 'fold':-1, 'models_to_load':${feature_types}, 'base_model':${base_model}}"
done


# epochs=150
# base_model="'full_dataset'"
# base_folder="'/tmp/full_dataset/'"


# for fold in $(seq 0 9); do
#     echo python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'epochs':${epochs}, 'fold':${fold}, 'base_model':${base_model}}"
#     python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'epochs':${epochs}, 'fold':${fold}, 'base_model':${base_model}}"
# done

#echo python3 experiment.py "{'seed':0,'base_folder':${base_folder}, 'epochs':${epochs}, 'fold':-1, 'base_model':${base_model}}"
#python3 experiment.py "{'seed':0,'base_folder':${base_folder}, 'epochs':${epochs}, 'fold':-1, 'base_model':${base_model}}"
# 
# binary_feature="True"
# feature_type="True"
# base_model="'full_dataset_tree'"
# base_folder="'/tmp/full_tree/'"
# for fold in $(seq 0 9); do
#     echo python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model},'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
#     python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model}, 'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
# done
# 
# echo python3 experiment.py "{'seed':0,'base_folder':${base_folder}, 'fold':-1, 'base_model':${base_model}, 'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
# python3 experiment.py "{'seed':0,'base_folder':${base_folder}, 'fold':-1, 'base_model':${base_model}, 'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"

# binary_feature="False"
# feature_type="'base_expression_gtex_features.csv'"
# base_model="'boosted_tree'"
# base_folder="'/tmp/gtex/'"
# for fold in $(seq 0 9); do
#     echo python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model},'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
#     python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model}, 'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
# done
# echo python3 experiment.py "{'seed':0,'base_folder':${base_folder}, 'fold':-1, 'base_model':${base_model}, 'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"

# binary_feature="True"
# feature_type="'go_features.csv'"
# base_model="'boosted_tree'"
# base_folder="'/tmp/go/'"
# 
# for fold in $(seq 0 9); do
#     echo python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model},'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
#     python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model}, 'feature_type':${feature_type}, 'binary_feature':${binary_feature}}"
# done


# models_to_load="['gtex', 'pathdip']"
# base_model="'joined_tree'"
# base_folder="'/tmp/gtex+pathdip/'"
# base_in_folder="'/tmp/'"
#
#
# for fold in $(seq 0 9); do
#     echo python3 experiment.py "{'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model},'models_to_load':${models_to_load}}"
#     python3 experiment.py "{'base_in_folder':${base_in_folder}, 'seed':0, 'base_folder':${base_folder}, 'fold':${fold}, 'base_model':${base_model}, 'models_to_load':${models_to_load}}"
# done
