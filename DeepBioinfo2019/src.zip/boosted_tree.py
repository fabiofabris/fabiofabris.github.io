from deep_learning_v2 import load_dataset
from deep_learning_v2 import train_model
from xgboost import XGBClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn import metrics


params={"silent":False, "n_estimators":100}

dl = load_dataset.DatasetLoader()
ds = dl.load_dataset("base_expression_gtex_features.csv", binary_features=False)
features, classes = train_model.PrepareDatasetDiseaseHie.prepare_dataset(ds)

clf_multilabel = OneVsRestClassifier(XGBClassifier(**params))
clf_multilabel.fit(features, classes)
predictions = clf_multilabel.predict_proba(features)
auroc = metrics.roc_auc_score(classes, predictions, average="weighted")
print(auroc)