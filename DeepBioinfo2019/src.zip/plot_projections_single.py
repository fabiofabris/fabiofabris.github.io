from sklearn.manifold import TSNE
from deep_learning_v2 import load_dataset
import sys


def generate_projection_file(encoded, has_class, out_file, labels):

    encoded = TSNE(n_components=2).fit_transform(encoded)

    with open(out_file, "w") as f:
        f.write(str(encoded.shape[0]) + "\n")

        for i in range(encoded.shape[0]):
            x = encoded[i, 0]
            y = encoded[i, 1]
            label = labels[i]

            f.write(",".join([str(label), str(x), str(y), str(has_class[label])])+"\n")


def main():
    dl = load_dataset.DatasetLoader()
    projection = dl.load_projection(sys.argv[1])
    out_file = sys.argv[2]

    class_name = "class_" + sys.argv[2].split("_")[-3]
    class_indexes = projection.class_indexes
    projection = projection.dropna(axis=0)

    classes = projection[class_indexes]
    features = projection.drop(labels=class_indexes, axis=1)

    generate_projection_file(features, classes.loc[:,class_name] > 0.5, out_file, features.index.tolist())


if __name__ == "__main__":
    main()
