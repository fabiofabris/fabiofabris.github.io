source ../../sourceMe

# python3 plot_projections.py ~/deep_exp/results/gtex/projections/_projection.csv ~/deep_exp/results/gtex/projections/
# python3 plot_projections.py ~/deep_exp/results/go/projections/_projection.csv ~/deep_exp/results/go/projections/
# python3 plot_projections.py ~/deep_exp/results/ppi/projections/_projection.csv ~/deep_exp/results/ppi/projections/
# python3 plot_projections.py ~/deep_exp/results/pathdip/projections/_projection.csv ~/deep_exp/results/pathdip/projections/


find /home/ff201/deep_exp/results_proj/go/projections/*.csv | xargs -P 3 -n 1 -I {} python3 plot_projections_single.py {} {}.2d
find /home/ff201/deep_exp/results_proj/ppi/projections/*.csv | xargs -P 3 -n 1 -I {} python3 plot_projections_single.py {} {}.2d
find /home/ff201/deep_exp/results_proj/pathdip/projections/*.csv | xargs -P 3 -n 1 -I {} python3 plot_projections_single.py {} {}.2d
find /home/ff201/deep_exp/results_proj/gtex/projections/*.csv | xargs -P 3 -n 1 -I {} python3 plot_projections_single.py {} {}.2d
find /home/ff201/deep_exp/results_proj/go+pathdip+ppi+gtex/projections/*.csv | xargs -P 3 -n 1 -I {} python3 plot_projections_single.py {} {}.2d

