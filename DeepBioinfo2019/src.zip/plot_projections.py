from sklearn.manifold import TSNE
from deep_learning_v2 import load_dataset
import sys


def generate_projection_file(encoded, classes, out_folder, labels):

    encoded = TSNE(n_components=2).fit_transform(encoded)

    for class_name in classes.columns.values:

        f_name = out_folder + "/2D_projection_" + class_name + ".csv"
        with open(f_name, "w") as f:
            has_class = classes.loc[:, class_name] > 0.5
            f.write(str(encoded.shape[0]) + "\n")

            for i in range(encoded.shape[0]):
                x = encoded[i, 0]
                y = encoded[i, 1]
                label = labels[i]

                f.write(",".join([str(label), str(x), str(y), str(has_class[label])])+"\n")


def main():
    dl = load_dataset.DatasetLoader()
    projection = dl.load_projection(sys.argv[1])
    out_folder = sys.argv[2]

    class_indexes = projection.class_indexes
    projection = projection.dropna(axis=0)

    classes = projection[class_indexes]
    features = projection.drop(labels=class_indexes, axis=1)

    generate_projection_file(features, classes, out_folder, features.index.tolist())


if __name__ == "__main__":
    main()
