package bioinfo_paper;

public class Main {
	public static void main(String[] args) throws Exception {
		
		Runner.main(new String[]{
				"/home/fabio/PostDoc/GeneticChangeWithAge/gcwa/docs/paper/submitted_src/go_expression.arff", // 0. DS file
				"/tmp/out.csv",  			// 1. outfile
				"100,200,300",  			// 2. [number of iterations] is the number of trees in the forest
				"0",  		// 3.  is the maximum depth of the trees in the forest (0 for unlimited).
				"0.5,1,2",  // 4.  [num. split] multiplier for number of random selected features to find a split, where the base value is sqrt(number of features).
				"1",  		// 5.  [seed] the seed for the RF algorithm.
				"true",  	// 6.  [sampleIB] re-sample in-bag instances (with undersampling).
				"10",		// 7.  [minInstAttr] N. of min. positive values
				"-1", 		// 8.  number of discretization bins (-1 for no discretization, "0" for unlimited bins)
				"false",  	// 9. apply CFS in the training sets
				});
	}

	
}
