package classificationExperiment;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.evaluation.ThresholdCurve;
import weka.classifiers.trees.PositiveValueStats;
import weka.classifiers.trees.RandomForest;
import weka.core.Attribute;
import weka.core.AttributeStats;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;

public class Util {
	public static String[] clasNames = { "class_disease_any", "class_disease_brain", "class_disease_heart",
			"class_disease_muscle", "class_expression_any", "class_expression_brain", "class_expression_heart",
			"class_expression_muscle" };

	/*
	 * Helper class to sort a map be the values of the elements.
	 */
	public static class MapUtil {
		public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {
			List<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(map.entrySet());
			Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
				public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
					return (o2.getValue()).compareTo(o1.getValue());
				}
			});

			Map<K, V> result = new LinkedHashMap<K, V>();
			for (Map.Entry<K, V> entry : list) {
				result.put(entry.getKey(), entry.getValue());
			}
			return result;
		}
	}
	
	
	/**
	 * Returns a Instances object representing the dataset.
	 * 
	 * @param datasetFileName
	 * @return
	 * @throws Exception
	 */
	public static Instances loadDataset(String datasetFileName) throws Exception {
		DataSource source = new DataSource(datasetFileName);
		Instances instances = source.getDataSet();
		return instances;
	}
	
	/**
	 * This method does several pre-processing steps: 1: Removes the first
	 * feature, which represents the Entrez id of the instance. 2: Removes
	 * attributes with less than "minAttrFreq" "1" values across the instances. 3: Removes
	 * the classes other than "clasName" 4: Remove class values annotating less
	 * than 5 instances.
	 * 
	 * @param clasNames
	 * @param clasName
	 * @param instances
	 * @param minAttrFreq
	 * @param featureListToRemove 
	 * @return
	 * @throws Exception
	 */
	public static Instances prepareDataset(String[] clasNames, String clasName, Instances instances, int minAttrFreq, 
			String[] additionalFeatureListToRemove) throws Exception {

		instances.setClass(instances.attribute(clasName));

		// adds to removeWithClass values the class ids with less than 5
		// instances
		ArrayList<Double> removeWithClassValue = new ArrayList<Double>();
		AttributeStats classAttributeStats = instances.attributeStats(instances.classIndex());
		for (int i = 0; i < classAttributeStats.nominalCounts.length; i++) {
			if (classAttributeStats.nominalCounts[i] < 5) {
				removeWithClassValue.add((double) i);
			}
		}

		for (int j = 0; j < instances.size(); j++) {
			if (removeWithClassValue.contains(instances.get(j).classValue())) {
				instances.get(j).setClassMissing();
			}
		}

		instances.deleteWithMissingClass();

		Remove remove = new Remove();
		ArrayList<Integer> toRemove = new ArrayList<Integer>();

		toRemove.add(0); // removing entrez id
		for (String toRemoveClas : clasNames) { // removes the classes other than clasName
			if (!toRemoveClas.equals(clasName)) {
				toRemove.add(instances.attribute(toRemoveClas).index());
			}
		}
		
		if(additionalFeatureListToRemove != null){
			for (String attribute: additionalFeatureListToRemove) {
				Attribute a = instances.attribute(attribute);
				if(a != null){
					toRemove.add(a.index());
					System.out.println("Removing attribute " + attribute);
				}
			}
		}

		// removes features with less than "minAttrFreq" occurrences. 
		for (int i = 0; i < instances.numAttributes(); i++) {
			if (instances.attributeStats(i).nominalCounts == null) {
				continue;
			}
			if (instances.attributeStats(i).nominalCounts[1] < minAttrFreq) {
				toRemove.add(i);
			}
		}

		int[] toRemoveArray = new int[toRemove.size()];
		for (int i = 0; i < toRemove.size(); i++) {
			toRemoveArray[i] = toRemove.get(i);
		}

		remove.setAttributeIndicesArray(toRemoveArray);
		remove.setInputFormat(instances);

		instances = Filter.useFilter(instances, remove);
		return instances;
	}
	

	/**
	 * This Method prints some statistics about the datasets in a latex-friendly
	 * way. Namely: the number of instances, the number of attributes and the
	 * distribution of each class label.
	 * 
	 * @param instances
	 * @param clasName
	 * @param datasetName
	 * @param writer
	 * @throws Exception
	 */
	public static void printDatasetStats(Instances instances, String clasName, String datasetName, PrintWriter writer)
			throws Exception {

		String clasDistri = "";

		AttributeStats dsStats = instances.attributeStats(instances.classIndex());
		for (int i = 0; i < dsStats.nominalCounts.length; i++) {
			if (dsStats.nominalCounts[i] > 0) {
				clasDistri += instances.classAttribute().value(i) + ":" + dsStats.nominalCounts[i] + " / ";
			}
		}

		writer.printf("STATS_LATEX_DB & %s & %s & %d & %d & %s \\\\ \n",
				datasetName.split("/")[datasetName.split("/").length - 1], clasName, instances.size(),
				instances.numAttributes(), clasDistri);
		
		writer.flush();
	}
	

	/**
	 * Simply converts an array of ints to a readable string representation (values are separated by commas).
	 * @param numFeatsSplit
	 * @return a string representing the array.
	 */
	public static String arrayToString(int[] numFeatsSplit) {
		StringBuilder ret = new StringBuilder();
		
		for(int n : numFeatsSplit){
			ret.append(n + ",");
		}
		
		return ret.toString();
	}
	
	/**
	 * Simply converts an array of ints to a readable string representation (values are separated by commas).
	 * @param numFeatsSplit
	 * @return a string representing the array.
	 */
	public static String arrayToString(double[] numFeatsSplit) {
		StringBuilder ret = new StringBuilder();
		
		for(double n : numFeatsSplit){
			ret.append(n + ",");
		}
		
		return ret.toString();
	}
	
	
	/**
	 * @param list: the String to be converted to an array. This is a list o integers separated by commas.
	 * @return: The converted int array.
	 */
	public static int[] parseStringToIntArray(String list) {
		String[] sList = list.split(",");
		int[] nList = new int[sList.length];
		
		for(int i = 0; i < nList.length; i++){
			nList[i] = Integer.parseInt(sList[i]);
		}
		
		return nList;
	}
	
	/**
	 * @param list: the String to be converted to an array. This is a list o integers separated by commas.
	 * @return: The converted double array.
	 */
	public static double[] parseStringToDoubleArray(String list) {
		String[] sList = list.split(",");
		double[] nList = new double[sList.length];
		
		for(int i = 0; i < nList.length; i++){
			nList[i] = Double.parseDouble(sList[i]);
		}
		
		return nList;
	}

	/**
	 * This method prints several classification statistics from Weka and also a
	 * Latex-friendly output containing the most relevant classification
	 * statistics.
	 * 
	 * The latex line contains, respectively: precision, recall, fmeasure, area
	 * under the ROC curve and area under the precision-recall curve. This
	 * information is printed for the weighted average for the class-wise
	 * performance and also for each individual class.
	 * This method also prints several threshold curves, namely:
	 * TPR,FPR,precision and recall and the associated probability threshold.
	 * 
	 * @param instances
	 * @param clasName
	 * @param datasetName
	 * @param eval
	 * @param writer
	 * @throws Exception
	 */
	public static void printClassificationStats(Instances instances, String clasName, String datasetName,
			Evaluation eval, PrintWriter writer) throws Exception {

		writer.println("CROSSVALID_STATS_BEGIN");
		writer.println(eval.toSummaryString());
		writer.println(eval.toClassDetailsString());
		writer.println(eval.toMatrixString());
		writer.println("CROSSVALID_STATS_END");

		double prc = eval.weightedAreaUnderPRC();
		double roc = eval.weightedAreaUnderROC();
		double pre = eval.weightedPrecision();
		double rec = eval.weightedRecall();
		double fm = eval.weightedFMeasure();


		writer.printf("STATS_LATEX_ACC & %s & %s & %.3f & %.3f & %.3f & %.3f & %.3f \\\\ \n",
				datasetName.split("/")[datasetName.split("/").length - 1], clasName, pre, rec, fm, roc, prc);

		AttributeStats dsStats = instances.attributeStats(instances.classIndex());
		for (int i = 0; i < dsStats.nominalCounts.length; i++) {
			if (dsStats.nominalCounts[i] > 0) {
				prc = eval.areaUnderPRC(i);
				roc = eval.areaUnderROC(i);
				pre = eval.precision(i);
				rec = eval.recall(i);
				fm = eval.fMeasure(i);
				writer.printf("STATS_LATEX_ACC_PER & %s & %s & %.3f & %.3f & %.3f & %.3f & %.3f & %s \\\\ \n",
						datasetName.split("/")[datasetName.split("/").length - 1], clasName, pre, rec, fm, roc, prc,
						instances.classAttribute().value(i));
			}
		}

		for (int classIndex = 0; classIndex < instances.numClasses(); classIndex++) {
			ThresholdCurve tc = new ThresholdCurve();
			Instances result = tc.getCurve(eval.predictions(), classIndex);
			for (int i = 0; i < result.size(); i++) {
				Instance instance = result.get(i);

				double ts = instance.value(result.attribute("Threshold"));
				double fpr = instance.value(result.attribute("False Positive Rate"));
				double tpr = instance.value(result.attribute("True Positive Rate"));
				double preTS = instance.value(result.attribute("Precision"));
				double recTS = instance.value(result.attribute("Recall"));

				writer.printf("ROCPOINTS_%s,%.4f,%.4f,%.4f,%.4f,%.4f\n", instances.classAttribute().value(classIndex),
						ts, fpr, tpr, preTS, recTS);
			}
		}
		
	}


	/**
	 * Prints the feature scores of the instances given by the random forest and
	 * the number of splits that used the feature.
	 * 
	 * @param instances
	 * @param classifier
	 * @param writer
	 * @throws Exception
	 */
	public static void printFeatureScores(Instances instances, RandomForest classifier, PrintWriter writer)
			throws Exception {
		Map<String, Double> impurityMap = new HashMap<String, Double>();
		Map<String, Double> numSelMap = new HashMap<String, Double>();

		double[] countPerAttr = new double[instances.numAttributes()];

		double[] impurityDecrease = ((RandomForest) classifier)
				.computeAverageImpurityDecreasePerAttribute(countPerAttr);
		for (int i = 0; i < impurityDecrease.length; i++) {
			if (impurityDecrease[i] > 0) {
				impurityMap.put(instances.attribute(i).name(), impurityDecrease[i]);
			}

			if (countPerAttr[i] > 0) {
				numSelMap.put(instances.attribute(i).name(), countPerAttr[i]);
			}
		}
		impurityMap = MapUtil.sortByValue(impurityMap);
		numSelMap = MapUtil.sortByValue(numSelMap);

		int i = 0;
		for (String k : impurityMap.keySet()) {
			writer.printf("IMP_SCORE,%d,%s,%2.4e,%2.4e\n", ++i, k, impurityMap.get(k), numSelMap.get(k));
		}

		i = 0;
		for (String k : numSelMap.keySet()) {
			writer.printf("IMP_SEL,%d,%s,%2.4e,%2.4e\n", ++i, k, numSelMap.get(k), impurityMap.get(k));
		}

		PositiveValueStats positiveStats = classifier.calculatePFVP(writer);
		positiveStats.printStats(writer, instances);

		classifier.printOOBConditionScores(writer);
		
		for(i = 0; i < instances.numClasses(); i++){
			classifier.printOOBConditionScores(writer, instances.classAttribute().value(i));
		}
	}


	
}
