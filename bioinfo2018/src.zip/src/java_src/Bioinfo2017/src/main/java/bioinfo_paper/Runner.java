package bioinfo_paper;

import java.io.PrintWriter;
import java.util.Random;

import classificationExperiment.Util;

import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.attribute.Discretize;

/**
 * @author Fabio Fabris
 * 
 *         This class performs the Random Forest experiments. It receives
 *         several parameters to set up the RF algorithm (see main method for
 *         details) and outputs classification performance statistics and
 *         feature importance statistics in a file.
 */
public class Runner {

	/**
	 * 
	 * This method receives several parameters to set up the experimental run of
	 * the RF algorithm. The predictive performance will be calculated using
	 * 10-fold cross-validation and the importance measures will be calculated
	 * using the whole dataset.
	 * 
	 * The parameters are:
	 * 
	 * 0. An arff file containing the instances. It is assumed that the last
	 * attribute is the class label.
	 * 
	 * 1. The path of the result file containing feature importance and
	 * predictive performance results. This file was designed to be easily
	 * filtered by using the "grep" command, so most lines are preceded by a
	 * label that can be easily filtered. Some are not because they are coming
	 * from weka, in this case they are encapsulated by special _BEGIN and _END
	 * labels.
	 * 
	 * This result file will contain:
	 * 
	 * a) The set-up of the RF algorithm (the value of all configurable
	 * parameters - label PARAM).
	 * 
	 * b) Dataset characteristics (filename, class name, number of instances,
	 * number of features and class label frequencies. - label STATS_LATEX_DB)
	 * 
	 * c) The predictive performance results of the cross validation procedure
	 * (Several error measures outputed by Weka, several accuracy measures per
	 * class and the confusion matrix - encapsulated by CROSSVALID_STATS_BEGIN,
	 * CROSSVALID_STATS_END)
	 * 
	 * d) The overall weighted accuracy (Precision, Recall, F-Measure, ROC Area,
	 * PRC Area - label STATS_LATEX_ACC)
	 * 
	 * e) Per-class accuracy measures (the same as (d) - label
	 * STATS_LATEX_ACC_PER)
	 * 
	 * f) Threshold statistics to calculate the ROC and PR curves for each label
	 * (Classification probability threshold, False Positive Rate, True Positive
	 * Rate, Precision, Recall - label ROCPOINTS_[class label] )
	 * 
	 * g) The time taken to run the cross-validation procedure to estimate
	 * predictive performance (label TIME)
	 * 
	 * The following values are calculated using the whole dataset for training.
	 * 
	 * h) The features sorted by ImpurityDecreasePerAttribute, calculated by
	 * weka on the OOB set (the last value is the number of times selected label
	 * IMP_SCORE).
	 * 
	 * i) The features sorted by the number of times they were selected,
	 * calculated by weka on the OOB set. (the last value is the
	 * ImpurityDecreasePerAttribute label IMP_SEL).
	 * 
	 * j) The convergence index of the COMPACT+ algorithm (defined as the Jaccard's
	 * distance between the top-20 features computed on iteration i and i + 1 of
	 * the RF algorithm. Where iteration i + 1 adds a new RT to the RF. A
	 * converge of 1 indicates that the top-20 features at iterations i and i+1
	 * are identical - label PFVP_CONV)
	 * 
	 * k) The overall and per class label number of OOB instances used by
	 * the COMPACT+ algorithm (totalOOBCount and oOBClassDistribution -
	 * label PFVP_TOTAL)
	 * 
	 * l) The COMPACT+ statistics per feature (label PFVP)
	 * 
	 * m) The IPM statistics for all classes and for each class (see
	 * Intervention in prediction measure: a new approach to assessing variable
	 * importance for random forests - label IPM_SCORE_OOB).
	 * 
	 * 2. The number of iterations (RTs in the RF). This can be a list of
	 * integers (separated by commas). If this is the case, this value will be
	 * optimised (with the number of randomly selected feature to test (mtry))
	 * using an internal 5-fold cross-validation procedure.
	 * 
	 * 3. The maximum depth of the RTs.
	 * 
	 * 4. The number of features to be randomly selected to create a split on
	 * the RTs.
	 * 
	 * 5. The random seed that controls the random number generator.
	 * 
	 * 6. Whether or not to perform in-bag under-sampling to balance the
	 * dataset.
	 * 
	 * 7. Number of in-bag instances with positive value (across all paths in the RF) that
	 * must occur in order for the positive condition to be considered.
	 * 
	 * 8. Number of discretization bins ("-1" for no discretization, "0" for unlimited bins)
	 * 
	 * 9. if "true" CFS will be run independently in each training fold of the cross-validation procedure and then at the end, using the
	 * whole dataset, to generate the model for interpretation.
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		if (args.length != 10) {
			System.out
					.println("Usage: java -jar RFInt.jar [dataset file] [outfile] [number of iterations] [max. depth] [seed] [sampleIB] " +
							"[minInstAttr] [discBins] [runCFS]");

			System.out.println("Where: [dataset file] is a arff file containing the instances.");
			System.out.println("[outfile] is where the information about the classification run will be printed.");
			System.out
					.println("[list of iterations] is the number of trees in the forest to be tested by the internal CV.");
			System.out.println("[max. depth] is the maximum depth of the trees in the forest.");
			System.out
					.println("[num. split] list of the number of random selected features to find a split to be tested by the internal CV.");
			System.out.println("[seed] the seed for the RF algorithm.");
			System.out.println("[sampleIB] undersample  inbag instances?.");
			System.out.println("[minInstAttr] N. of min. positive values.");
			System.out.println("[discBins] N. of discreitization bins.");
			System.out.println("[runCFS] If \"true\" CFS will be run in the training folds of the cross-validation procedure and at the" +
					"end, when using the full dataset to generate the interpretation results. Note that the results of CFS in the final" +
					"run (using the whole dataset) are always the same.");
			return;
		}

		// parses the parameters
		String datasetFileName = args[0];
		String outFileName = args[1];
		int[] iterations = Util.parseStringToIntArray(args[2]);
		int maxDepth = Integer.parseInt(args[3]);
		double[] numFeatsSplitMulti = Util.parseStringToDoubleArray(args[4]);
		int seed = Integer.parseInt(args[5]);
		boolean sampleIB = Boolean.parseBoolean(args[6]);
		int minAttrFreq = Integer.parseInt(args[7]);
		int nBins = Integer.parseInt(args[8]);
		boolean useCFS = Boolean.parseBoolean(args[9]);

		System.out.println("Out file name: " + outFileName);
		System.out.flush();

		PrintWriter writer = new PrintWriter(outFileName, "UTF-8");

		// prints the parameters
		writer.println("PARAM, Using dataset: " + datasetFileName);
		writer.println("PARAM, Number of iterations: " + Util.arrayToString(iterations));
		writer.println("PARAM, Max. depth: " + maxDepth);
		writer.println("PARAM, Random seed: " + seed);
		writer.println("PARAM, Number of random selected features used in each split: "
				+ Util.arrayToString(numFeatsSplitMulti));
		writer.println("PARAM, Do IB undersample: " + sampleIB);
		writer.println("PARAM, N. of min. positive values: " + minAttrFreq);
		writer.println("PARAM, N. bins: " + nBins);
		writer.println("PARAM, Use cfs: " + useCFS);

		writer.flush();



		// loads the dataset, sets the class index and prints the dataset statistics.
		Instances instances = Util.loadDataset(datasetFileName);
		instances.setClassIndex(instances.numAttributes()-1);
		Util.printDatasetStats(instances, instances.classAttribute().name(), datasetFileName, writer);

		// does the actual classification and prints the results of the
		// predictive performance and interpretation measures.
		doClassification(instances, instances.classAttribute().name(), datasetFileName, writer, iterations, maxDepth, numFeatsSplitMulti, 
				seed, 0.0, 1, sampleIB, false, false, false, nBins, useCFS);

		writer.close();
	}

	private static void doClassification(Instances instances, String clasName, String datasetFileName,
			PrintWriter writer, int[] iterations, int maxDepth, double[] numFeatsSplitMulti, int seed, double probTs,
			int minCov, boolean sampleIB, boolean sampleOB, boolean sampleIBOverSmote, boolean sampleIBOverResub, int nBins, boolean doCFS)
			throws Exception {

		Evaluation eval = new Evaluation(instances);
		RandomForest classifier = new RandomForest(probTs, minCov);

		// sets the parameters
		classifier.setComputeAttributeImportance(true);
		classifier.setCalcOutOfBag(true);
		classifier.setNumIterationsInternalCV(iterations);
		classifier.setMaxDepth(maxDepth);
		classifier.setNumFeaturesInternalCV(numFeatsSplitMulti);
		classifier.setResampleBalancedIB(sampleIB);
		classifier.setResampleBalancedIBOOB(sampleOB);
		classifier.setResampleBalancedIBOverSmote(sampleIBOverSmote);
		classifier.setResampleBalancedIBOverResub(sampleIBOverResub);
		classifier.setSeed(seed);
		classifier.doInternalCV(true);
		classifier.doCFS(doCFS);

		// performs the 10 fold cross validation procedure, recording the
		// running time.
		long before = System.currentTimeMillis();
		
		if (nBins != -1) {
			Discretize filter = new Discretize();
			filter.setNBins(nBins);
			eval.setFilter(filter);
		}
		
		eval.crossValidateModel(classifier, instances, 10, new Random(seed));
		Util.printClassificationStats(instances, clasName, datasetFileName, eval, writer);
		long after = System.currentTimeMillis() - before;
		writer.printf("TIME,Seconds taken for cross-validation,%f.\n", ((double) after) / 1000.0);
		writer.flush();

		if (nBins != -1) {
			Discretize filter = new Discretize();
			filter.setNBins(nBins);
			filter.setInputFormat(instances);
			instances = Filter.useFilter(instances, filter);
		}

		classifier.setBestInternalCVParameters();
		classifier.doInternalCV(false);

		
		classifier.buildClassifier(instances); // train final model with all
												// data
		Util.printFeatureScores(instances, classifier, writer); // prints the
																// feature
																// statistics

		// uncomment these two lines if you want to see the classification models
		// classifier.setPrintClassifiers(true);											
		// System.out.println(classifier);

	}

}
