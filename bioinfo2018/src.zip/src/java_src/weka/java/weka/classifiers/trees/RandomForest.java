/*
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 *    RandomForest.java
 *    Copyright (C) 2001-2012 University of Waikato, Hamilton, New Zealand
 *
 */

package weka.classifiers.trees;

import weka.attributeSelection.BestFirst;
import weka.attributeSelection.CfsSubsetEval;
import weka.classifiers.AbstractClassifier;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.meta.Bagging;
import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionUtils;
import weka.core.TechnicalInformation;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;
import weka.core.Utils;
import weka.core.WekaException;
import weka.filters.Filter;
import weka.filters.supervised.attribute.AttributeSelection;
import weka.gui.ProgrammaticProperty;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Vector;

/**
 * <!-- globalinfo-start --> Class for constructing a forest of random trees.<br>
 * <br>
 * For more information see: <br>
 * <br>
 * Leo Breiman (2001). Random Forests. Machine Learning. 45(1):5-32. <br>
 * <br>
 * <!-- globalinfo-end -->
 * 
 * <!-- technical-bibtex-start --> BibTeX:
 * 
 * <pre>
 * &#64;article{Breiman2001,
 *    author = {Leo Breiman},
 *    journal = {Machine Learning},
 *    number = {1},
 *    pages = {5-32},
 *    title = {Random Forests},
 *    volume = {45},
 *    year = {2001}
 * }
 * </pre>
 * 
 * <br>
 * <br>
 * <!-- technical-bibtex-end -->
 * 
 * <!-- options-start --> Valid options are:
 * <p>
 * 
 * <pre>
 * -P
 *  Size of each bag, as a percentage of the
 *  training set size. (default 100)
 * </pre>
 * 
 * <pre>
 * -O
 *  Calculate the out of bag error.
 * </pre>
 * 
 * <pre>
 * -store-out-of-bag-predictions
 *  Whether to store out of bag predictions in internal evaluation object.
 * </pre>
 * 
 * <pre>
 * -output-out-of-bag-complexity-statistics
 *  Whether to output complexity-based statistics when out-of-bag evaluation is performed.
 * </pre>
 * 
 * <pre>
 * -print
 *  Print the individual classifiers in the output
 * </pre>
 * 
 * <pre>
 * -attribute-importance
 *  Compute and output attribute importance (mean impurity decrease method)
 * </pre>
 * 
 * <pre>
 * -I &lt;num&gt;
 *  Number of iterations.
 *  (current value 100)
 * </pre>
 * 
 * <pre>
 * -num-slots &lt;num&gt;
 *  Number of execution slots.
 *  (default 1 - i.e. no parallelism)
 *  (use 0 to auto-detect number of cores)
 * </pre>
 * 
 * <pre>
 * -K &lt;number of attributes&gt;
 *  Number of attributes to randomly investigate. (default 0)
 *  (&lt;1 = int(log_2(#predictors)+1)).
 * </pre>
 * 
 * <pre>
 * -M &lt;minimum number of instances&gt;
 *  Set minimum number of instances per leaf.
 *  (default 1)
 * </pre>
 * 
 * <pre>
 * -V &lt;minimum variance for split&gt;
 *  Set minimum numeric class variance proportion
 *  of train variance for split (default 1e-3).
 * </pre>
 * 
 * <pre>
 * -S &lt;num&gt;
 *  Seed for random number generator.
 *  (default 1)
 * </pre>
 * 
 * <pre>
 * -depth &lt;num&gt;
 *  The maximum depth of the tree, 0 for unlimited.
 *  (default 0)
 * </pre>
 * 
 * <pre>
 * -N &lt;num&gt;
 *  Number of folds for backfitting (default 0, no backfitting).
 * </pre>
 * 
 * <pre>
 * -U
 *  Allow unclassified instances.
 * </pre>
 * 
 * <pre>
 * -B
 *  Break ties randomly when several attributes look equally good.
 * </pre>
 * 
 * <pre>
 * -output-debug-info
 *  If set, classifier is run in debug mode and
 *  may output additional info to the console
 * </pre>
 * 
 * <pre>
 * -do-not-check-capabilities
 *  If set, classifier capabilities are not checked before classifier is built
 *  (use with caution).
 * </pre>
 * 
 * <pre>
 * -num-decimal-places
 *  The number of decimal places for the output of numbers in the model (default 2).
 * </pre>
 * 
 * <pre>
 * -batch-size
 *  The desired batch size for batch prediction  (default 100).
 * </pre>
 * 
 * <!-- options-end -->
 * 
 * @author Richard Kirkby (rkirkby@cs.waikato.ac.nz)
 * @version $Revision: 13295 $
 */
public class RandomForest extends Bagging {

	/** for serialization */
	static final long serialVersionUID = 1116839470751428698L;

	/** True to compute attribute importance */
	protected boolean m_computeAttributeImportance;

	// The next features were added to customise the RF code.

	/*
	 * If "true" will perform the internal cross-validation process to tune the
	 * parameters.
	 * 
	 * All pairwise combination of the arrays "numFeatsSplit" and "iterations"
	 * will be tested and the best one will be used for a particular fold.
	 */
	private boolean doInternalCV = false;

	/*
	 * An array containing in each position, how many features will be randomly
	 * sampled to selected the best feature to split the data in the RF.
	 */
	private double[] numFeatsSplitMultiArray;

	/*
	 * An array containing in each position, how may trees will be present in
	 * the random forest.
	 */
	private int[] iterations;

	/*
	 * If true, 5-fold internal cross-validation will be performed to find the
	 * value of the parameters numFeatsSplit and iterations
	 */
	private boolean performingInternalClassification;

	private boolean doCFS = false;

	private AttributeSelection filter;

	/*
	 * Record the number of times each parameter was the best.
	 */

	private static HashMap<ArrayList<Integer>, Integer> bestParamMap;

	/**
	 * The default number of iterations to perform.
	 */
	@Override
	protected int defaultNumberOfIterations() {
		return 100;
	}

	/**
	 * Constructor that sets base classifier for bagging to RandomTree and
	 * default number of iterations to 100.
	 */
	public RandomForest() {

		RandomTree rTree = new RandomTree();

		rTree.setDoNotCheckCapabilities(true);
		super.setClassifier(rTree);
		super.setRepresentCopiesUsingWeights(true);
		setNumIterations(defaultNumberOfIterations());

		bestParamMap = new HashMap<ArrayList<Integer>, Integer>();

	}

	/**
	 * Constructor that sets base classifier for bagging to RandomTree and
	 * default number of iterations to 100.
	 * 
	 * This constructor also sets the parameters coverageTS (the minimum
	 * coverage that a path must have in order to be considered for the PPC
	 * algorithm) and probTS (the minimum assigned probability for the majority
	 * class that a path must have for the path to be considered for the PPC
	 * algorithm).
	 */
	public RandomForest(double probTS, int coverageTS) {

		RandomTree rTree = new RandomTree();
		rTree.setProbTS(probTS);
		rTree.setCoverageTS(coverageTS);

		rTree.setDoNotCheckCapabilities(true);
		super.setClassifier(rTree);
		super.setRepresentCopiesUsingWeights(true);
		setNumIterations(defaultNumberOfIterations());

		bestParamMap = new HashMap<ArrayList<Integer>, Integer>();

	}

	/**
	 * Returns default capabilities of the base classifier.
	 * 
	 * @return the capabilities of the base classifier
	 */
	public Capabilities getCapabilities() {

		// Cannot use the main RandomTree object because capabilities checking
		// has
		// been turned off
		// for that object.
		return (new RandomTree()).getCapabilities();
	}

	/**
	 * String describing default classifier.
	 * 
	 * @return the default classifier classname
	 */
	@Override
	protected String defaultClassifierString() {

		return "weka.classifiers.trees.RandomTree";
	}

	/**
	 * String describing default classifier options.
	 * 
	 * @return the default classifier options
	 */
	@Override
	protected String[] defaultClassifierOptions() {

		String[] args = { "-do-not-check-capabilities" };
		return args;
	}

	/**
	 * Returns a string describing classifier
	 * 
	 * @return a description suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String globalInfo() {

		return "Class for constructing a forest of random trees.\n\n" + "For more information see: \n\n"
				+ getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	@Override
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR, "Leo Breiman");
		result.setValue(Field.YEAR, "2001");
		result.setValue(Field.TITLE, "Random Forests");
		result.setValue(Field.JOURNAL, "Machine Learning");
		result.setValue(Field.VOLUME, "45");
		result.setValue(Field.NUMBER, "1");
		result.setValue(Field.PAGES, "5-32");

		return result;
	}

	/**
	 * This method only accepts RandomTree arguments.
	 * 
	 * @param newClassifier
	 *            the RandomTree to use.
	 * @exception if
	 *                argument is not a RandomTree
	 */
	@Override
	@ProgrammaticProperty
	public void setClassifier(Classifier newClassifier) {
		if (!(newClassifier instanceof RandomTree)) {
			throw new IllegalArgumentException("RandomForest: Argument of setClassifier() must be a RandomTree.");
		}
		super.setClassifier(newClassifier);
	}

	/**
	 * This method only accepts true as its argument
	 * 
	 * @param representUsingWeights
	 *            must be set to true.
	 * @exception if
	 *                argument is not true
	 */
	@Override
	@ProgrammaticProperty
	public void setRepresentCopiesUsingWeights(boolean representUsingWeights) {
		if (!representUsingWeights) {
			throw new IllegalArgumentException(
					"RandomForest: Argument of setRepresentCopiesUsingWeights() must be true.");
		}
		super.setRepresentCopiesUsingWeights(representUsingWeights);
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String numFeaturesTipText() {
		return ((RandomTree) getClassifier()).KValueTipText();
	}

	/**
	 * Get the number of features used in random selection.
	 * 
	 * @return Value of numFeatures.
	 */
	public int getNumFeatures() {

		return ((RandomTree) getClassifier()).getKValue();
	}

	/**
	 * Set the number of features to use in random selection.
	 * 
	 * @param newNumFeatures
	 *            Value to assign to numFeatures.
	 */
	public void setNumFeatures(int newNumFeatures) {

		((RandomTree) getClassifier()).setKValue(newNumFeatures);
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String computeAttributeImportanceTipText() {
		return "Compute attribute importance via mean impurity decrease";
	}

	/**
	 * Set whether to compute and output attribute importance scores
	 * 
	 * @param computeAttributeImportance
	 *            true to compute attribute importance scores
	 */
	public void setComputeAttributeImportance(boolean computeAttributeImportance) {
		m_computeAttributeImportance = computeAttributeImportance;
		((RandomTree) m_Classifier).setComputeImpurityDecreases(computeAttributeImportance);
	}

	/**
	 * Get whether to compute and output attribute importance scores
	 * 
	 * @return true if computing attribute importance scores
	 */
	public boolean getComputeAttributeImportance() {
		return m_computeAttributeImportance;
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String maxDepthTipText() {
		return ((RandomTree) getClassifier()).maxDepthTipText();
	}

	/**
	 * Get the maximum depth of trh tree, 0 for unlimited.
	 * 
	 * @return the maximum depth.
	 */
	public int getMaxDepth() {
		return ((RandomTree) getClassifier()).getMaxDepth();
	}

	/**
	 * Set the maximum depth of the tree, 0 for unlimited.
	 * 
	 * @param value
	 *            the maximum depth.
	 */
	public void setMaxDepth(int value) {
		((RandomTree) getClassifier()).setMaxDepth(value);
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String breakTiesRandomlyTipText() {
		return ((RandomTree) getClassifier()).breakTiesRandomlyTipText();
	}

	/**
	 * Get whether to break ties randomly.
	 * 
	 * @return true if ties are to be broken randomly.
	 */
	public boolean getBreakTiesRandomly() {

		return ((RandomTree) getClassifier()).getBreakTiesRandomly();
	}

	/**
	 * Set whether to break ties randomly.
	 * 
	 * @param newBreakTiesRandomly
	 *            true if ties are to be broken randomly
	 */
	public void setBreakTiesRandomly(boolean newBreakTiesRandomly) {

		((RandomTree) getClassifier()).setBreakTiesRandomly(newBreakTiesRandomly);
	}

	/**
	 * Set debugging mode.
	 * 
	 * @param debug
	 *            true if debug output should be printed
	 */
	public void setDebug(boolean debug) {

		super.setDebug(debug);
		((RandomTree) getClassifier()).setDebug(debug);
	}

	/**
	 * Set the number of decimal places.
	 */
	public void setNumDecimalPlaces(int num) {

		super.setNumDecimalPlaces(num);
		((RandomTree) getClassifier()).setNumDecimalPlaces(num);
	}

	/**
	 * Set the preferred batch size for batch prediction.
	 * 
	 * @param size
	 *            the batch size to use
	 */
	@Override
	public void setBatchSize(String size) {

		super.setBatchSize(size);
		((RandomTree) getClassifier()).setBatchSize(size);
	}

	/**
	 * Sets the seed for the random number generator.
	 * 
	 * @param s
	 *            the seed to be used
	 */
	public void setSeed(int s) {

		super.setSeed(s);
		((RandomTree) getClassifier()).setSeed(s);
	}

	/**
	 * Returns description of the bagged classifier.
	 * 
	 * @return description of the bagged classifier as a string
	 */
	@Override
	public String toString() {

		if (m_Classifiers == null) {
			return "RandomForest: No model built yet.";
		}
		StringBuilder buffer = new StringBuilder("RandomForest\n\n");
		buffer.append(super.toString());

		if (getComputeAttributeImportance()) {
			try {
				double[] nodeCounts = new double[m_data.numAttributes()];
				double[] impurityScores = computeAverageImpurityDecreasePerAttribute(nodeCounts);
				int[] sortedIndices = Utils.sort(impurityScores);
				buffer.append("\n\nAttribute importance based on average impurity decrease "
						+ "(and number of nodes using that attribute)\n\n");
				for (int i = sortedIndices.length - 1; i >= 0; i--) {
					int index = sortedIndices[i];
					if (index != m_data.classIndex()) {
						buffer.append(Utils.doubleToString(impurityScores[index], 10, getNumDecimalPlaces()))
								.append(" (").append(Utils.doubleToString(nodeCounts[index], 6, 0)).append(")  ")
								.append(m_data.attribute(index).name()).append("\n");
					}
				}
			} catch (WekaException ex) {
				// ignore
			}
		}

		return buffer.toString();
	}

	/**
	 * Computes the average impurity decrease per attribute over the trees
	 * 
	 * @param nodeCounts
	 *            an optional array that, if non-null, will hold the count of
	 *            the number of nodes at which each attribute was used for
	 *            splitting
	 * @return the average impurity decrease per attribute over the trees
	 */
	public double[] computeAverageImpurityDecreasePerAttribute(double[] nodeCounts) throws WekaException {

		if (m_Classifiers == null) {
			throw new WekaException("Classifier has not been built yet!");
		}

		if (!getComputeAttributeImportance()) {
			throw new WekaException("Stats for attribute importance have not " + "been collected!");
		}

		double[] impurityDecreases = new double[m_data.numAttributes()];
		if (nodeCounts == null) {
			nodeCounts = new double[m_data.numAttributes()];
		}
		for (Classifier c : m_Classifiers) {
			double[][] forClassifier = ((RandomTree) c).getImpurityDecreases();
			for (int i = 0; i < m_data.numAttributes(); i++) {
				impurityDecreases[i] += forClassifier[i][0];
				nodeCounts[i] += forClassifier[i][1];
			}
		}
		for (int i = 0; i < m_data.numAttributes(); i++) {
			if (nodeCounts[i] > 0) {
				impurityDecreases[i] /= nodeCounts[i];
			}
		}

		return impurityDecreases;
	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options
	 */
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> newVector = new Vector<Option>();

		newVector.addElement(new Option("\tSize of each bag, as a percentage of the\n"
				+ "\ttraining set size. (default 100)", "P", 1, "-P"));

		newVector.addElement(new Option("\tCalculate the out of bag error.", "O", 0, "-O"));

		newVector.addElement(new Option("\tWhether to store out of bag predictions in internal evaluation object.",
				"store-out-of-bag-predictions", 0, "-store-out-of-bag-predictions"));

		newVector.addElement(new Option(
				"\tWhether to output complexity-based statistics when out-of-bag evaluation is performed.",
				"output-out-of-bag-complexity-statistics", 0, "-output-out-of-bag-complexity-statistics"));

		newVector.addElement(new Option("\tPrint the individual classifiers in the output", "print", 0, "-print"));

		newVector.addElement(new Option("\tCompute and output attribute importance (mean impurity decrease "
				+ "method)", "attribute-importance", 0, "-attribute-importance"));

		newVector.addElement(new Option("\tNumber of iterations.\n" + "\t(current value " + getNumIterations() + ")",
				"I", 1, "-I <num>"));

		newVector.addElement(new Option("\tNumber of execution slots.\n" + "\t(default 1 - i.e. no parallelism)\n"
				+ "\t(use 0 to auto-detect number of cores)", "num-slots", 1, "-num-slots <num>"));

		// Add base classifier options
		List<Option> list = Collections.list(((OptionHandler) getClassifier()).listOptions());
		newVector.addAll(list);

		return newVector.elements();
	}

	/**
	 * Gets the current settings of the forest.
	 * 
	 * @return an array of strings suitable for passing to setOptions()
	 */
	@Override
	public String[] getOptions() {
		Vector<String> result = new Vector<String>();

		result.add("-P");
		result.add("" + getBagSizePercent());

		if (getCalcOutOfBag()) {
			result.add("-O");
		}

		if (getStoreOutOfBagPredictions()) {
			result.add("-store-out-of-bag-predictions");
		}

		if (getOutputOutOfBagComplexityStatistics()) {
			result.add("-output-out-of-bag-complexity-statistics");
		}

		if (getPrintClassifiers()) {
			result.add("-print");
		}

		if (getComputeAttributeImportance()) {
			result.add("-attribute-importance");
		}

		result.add("-I");
		result.add("" + getNumIterations());

		result.add("-num-slots");
		result.add("" + getNumExecutionSlots());

		if (getDoNotCheckCapabilities()) {
			result.add("-do-not-check-capabilities");
		}

		// Add base classifier options
		Vector<String> classifierOptions = new Vector<String>();
		Collections.addAll(classifierOptions, ((OptionHandler) getClassifier()).getOptions());
		Option.deleteFlagString(classifierOptions, "-do-not-check-capabilities");
		result.addAll(classifierOptions);

		return result.toArray(new String[result.size()]);
	}

	/**
	 * Parses a given list of options.
	 * <p/>
	 * 
	 * <!-- options-start --> Valid options are:
	 * <p>
	 * 
	 * <pre>
	 * -P
	 *  Size of each bag, as a percentage of the
	 *  training set size. (default 100)
	 * </pre>
	 * 
	 * <pre>
	 * -O
	 *  Calculate the out of bag error.
	 * </pre>
	 * 
	 * <pre>
	 * -store-out-of-bag-predictions
	 *  Whether to store out of bag predictions in internal evaluation object.
	 * </pre>
	 * 
	 * <pre>
	 * -output-out-of-bag-complexity-statistics
	 *  Whether to output complexity-based statistics when out-of-bag evaluation is performed.
	 * </pre>
	 * 
	 * <pre>
	 * -print
	 *  Print the individual classifiers in the output
	 * </pre>
	 * 
	 * <pre>
	 * -attribute-importance
	 *  Compute and output attribute importance (mean impurity decrease method)
	 * </pre>
	 * 
	 * <pre>
	 * -I &lt;num&gt;
	 *  Number of iterations.
	 *  (current value 100)
	 * </pre>
	 * 
	 * <pre>
	 * -num-slots &lt;num&gt;
	 *  Number of execution slots.
	 *  (default 1 - i.e. no parallelism)
	 *  (use 0 to auto-detect number of cores)
	 * </pre>
	 * 
	 * <pre>
	 * -K &lt;number of attributes&gt;
	 *  Number of attributes to randomly investigate. (default 0)
	 *  (&lt;1 = int(log_2(#predictors)+1)).
	 * </pre>
	 * 
	 * <pre>
	 * -M &lt;minimum number of instances&gt;
	 *  Set minimum number of instances per leaf.
	 *  (default 1)
	 * </pre>
	 * 
	 * <pre>
	 * -V &lt;minimum variance for split&gt;
	 *  Set minimum numeric class variance proportion
	 *  of train variance for split (default 1e-3).
	 * </pre>
	 * 
	 * <pre>
	 * -S &lt;num&gt;
	 *  Seed for random number generator.
	 *  (default 1)
	 * </pre>
	 * 
	 * <pre>
	 * -depth &lt;num&gt;
	 *  The maximum depth of the tree, 0 for unlimited.
	 *  (default 0)
	 * </pre>
	 * 
	 * <pre>
	 * -N &lt;num&gt;
	 *  Number of folds for backfitting (default 0, no backfitting).
	 * </pre>
	 * 
	 * <pre>
	 * -U
	 *  Allow unclassified instances.
	 * </pre>
	 * 
	 * <pre>
	 * -B
	 *  Break ties randomly when several attributes look equally good.
	 * </pre>
	 * 
	 * <pre>
	 * -output-debug-info
	 *  If set, classifier is run in debug mode and
	 *  may output additional info to the console
	 * </pre>
	 * 
	 * <pre>
	 * -do-not-check-capabilities
	 *  If set, classifier capabilities are not checked before classifier is built
	 *  (use with caution).
	 * </pre>
	 * 
	 * <pre>
	 * -num-decimal-places
	 *  The number of decimal places for the output of numbers in the model (default 2).
	 * </pre>
	 * 
	 * <pre>
	 * -batch-size
	 *  The desired batch size for batch prediction  (default 100).
	 * </pre>
	 * 
	 * <!-- options-end -->
	 * 
	 * @param options
	 *            the list of options as an array of strings
	 * @throws Exception
	 *             if an option is not supported
	 */
	@Override
	public void setOptions(String[] options) throws Exception {

		String bagSize = Utils.getOption('P', options);
		if (bagSize.length() != 0) {
			setBagSizePercent(Integer.parseInt(bagSize));
		} else {
			setBagSizePercent(100);
		}

		setCalcOutOfBag(Utils.getFlag('O', options));

		setStoreOutOfBagPredictions(Utils.getFlag("store-out-of-bag-predictions", options));

		setOutputOutOfBagComplexityStatistics(Utils.getFlag("output-out-of-bag-complexity-statistics", options));

		setPrintClassifiers(Utils.getFlag("print", options));

		setComputeAttributeImportance(Utils.getFlag("attribute-importance", options));

		String iterations = Utils.getOption('I', options);
		if (iterations.length() != 0) {
			setNumIterations(Integer.parseInt(iterations));
		} else {
			setNumIterations(defaultNumberOfIterations());
		}

		String numSlots = Utils.getOption("num-slots", options);
		if (numSlots.length() != 0) {
			setNumExecutionSlots(Integer.parseInt(numSlots));
		} else {
			setNumExecutionSlots(1);
		}

		RandomTree classifier = ((RandomTree) AbstractClassifier.forName(defaultClassifierString(), options));
		classifier.setComputeImpurityDecreases(m_computeAttributeImportance);
		setDoNotCheckCapabilities(classifier.getDoNotCheckCapabilities());
		setSeed(classifier.getSeed());
		setDebug(classifier.getDebug());
		setNumDecimalPlaces(classifier.getNumDecimalPlaces());
		setBatchSize(classifier.getBatchSize());
		classifier.setDoNotCheckCapabilities(true);

		// Set base classifier and options
		setClassifier(classifier);

		Utils.checkForRemainingOptions(options);
	}

	/**
	 * Returns the revision string.
	 * 
	 * @return the revision
	 */
	@Override
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 13295 $");
	}

	/**
	 * Main method for this class.
	 * 
	 * @param argv
	 *            the options
	 */
	public static void main(String[] argv) {
		runClassifier(new RandomForest(), argv);
	}

	/**
	 * 
	 * This method calculates the PFVPs (Positive Feature Value Performances)
	 * for every feature and class label.
	 * 
	 * The PFVPs are calculated by first iterating over all trees in the forest.
	 * For each tree we classify each OOB instance using the tree. For each
	 * classified instance we retrieve the predicted class, the actual class,
	 * and the features with value 1 (the positive features) that were used to
	 * classify the instance. With this information we increment 2 maps
	 * counters:
	 * 
	 * 1: the number of times the feature was used to label an instance with a
	 * particular class value. (see StatisticsForFeatures.coveragePerClas) 2:
	 * Same as (1) and the classification was correct (see
	 * StatisticsForFeatures.hitsPerClas).
	 * 
	 * This method also retrieves two pieces of information that are independent
	 * of the decision trees: 1: totalOOBCount: The total number of OOB
	 * instances across all trees. 2: OOBClassDistribution: The class
	 * distribution of all OOB instances.
	 * 
	 * @return
	 * @throws Exception
	 */
	public PositiveValueStats calculatePFVP(PrintWriter writer) throws Exception {
		if (this.m_Classifiers == null) {
			throw new Exception("Random forest not available. Has the model been trained?");
		}

		// the total number of OOB instances (if the same instance occurs in n
		// out bags its counted n times.)
		double totalOOBCount = getTotalOOBCount();

		// the summed-up class distribution across all out-bags.
		HashMap<String, Integer> OOBClassDistribution = getOOBClassDistribution();

		// initialising the statistics object that will hold the counts
		PositiveValueStats statistics = new PositiveValueStats(totalOOBCount, OOBClassDistribution,
				this.m_data.numClasses());

		HashMap<String, HashSet<String>> curTopFeatures = null;
		HashMap<String, HashSet<String>> lastTopFeatures = null;

		for (int i = 0; i < m_Classifiers.length; i++) {

			// Instances object to hold the OOB instances.
			Instances instances = new Instances(this.m_data, 0, 0);

			ArrayList<Integer> indexes = new ArrayList<Integer>();
			for (int j = 0; j < this.m_inBag[i].length; j++) {
				if (!this.m_inBag[i][j]) {
					instances.add(this.m_data.get(j));
					indexes.add(j);
				}
			}

			// returns an object containing the totalOOBCount and
			// OOBClassDistribution counts and updates the statistics.
			StatisticsForFeatures statisticsForFeatures = ((RandomTree) m_Classifiers[i]).getOOBStatisticsForFeatures(
					instances, indexes, i);
			statistics.update(statisticsForFeatures);

			curTopFeatures = statistics.getTopFeatures(this.m_data);

			if (lastTopFeatures != null) {
				writer.printf("PFVP_CONV,%d,", i);
				for (String clas : lastTopFeatures.keySet()) {
					double distance = RandomForest.jacardDistance(lastTopFeatures.get(clas), curTopFeatures.get(clas));
					writer.printf("PFVP_CONV,Cla:%s,jac:%.4f,", clas, distance);
				}
				writer.printf("\n");
			}
			lastTopFeatures = curTopFeatures;

		}

		return statistics;
	}

	/**
	 * Calculates the jacard distance between the sets hashSet and hashSet2
	 * 
	 * @param hashSet
	 * @param hashSet2
	 * @return
	 */
	private static double jacardDistance(HashSet<String> hashSet, HashSet<String> hashSet2) {

		HashSet<String> hashSetCopy = new HashSet<String>(hashSet);
		HashSet<String> hashSe2tCopy = new HashSet<String>(hashSet2);

		hashSetCopy.retainAll(hashSe2tCopy);
		int interSize = hashSetCopy.size();

		hashSetCopy = new HashSet<String>(hashSet);
		hashSe2tCopy = new HashSet<String>(hashSet2);
		hashSetCopy.addAll(hashSe2tCopy);

		int unionSize = hashSetCopy.size();

		return ((double) interSize) / ((double) unionSize);
	}

	/**
	 * Returns the summation of the class distributions for each OOB set.
	 * 
	 * @return
	 */
	private HashMap<String, Integer> getOOBClassDistribution() {
		HashMap<String, Integer> ret = new HashMap<String, Integer>();
		for (int i = 0; i < this.m_Classifiers.length; i++) { // for each bag
			for (int j = 0; j < this.m_inBag[i].length; j++)
				if (!this.m_inBag[i][j]) {
					String instanceClassName = this.m_data.get(j).classAttribute()
							.value((int) this.m_data.get(j).classValue());

					Integer c = ret.get(instanceClassName);
					if (c != null) {
						ret.put(instanceClassName, c + 1);
					} else {
						ret.put(instanceClassName, 1);
					}
				}
		}
		return ret;
	}

	/**
	 * Returns summation of the size of all OOB sets.
	 * 
	 * @return
	 */
	private int getTotalOOBCount() {
		int ret = 0;
		for (int i = 0; i < this.m_Classifiers.length; i++) { // for each bag
			int bag = 0;
			for (int j = 0; j < this.m_inBag[i].length; j++) {
				if (!this.m_inBag[i][j]) {
					bag += 1;
				}
			}
			ret += bag;
		}
		return ret;
	}

	/**
	 * Divides the values of the map "map" by the number "v".
	 * 
	 * @param map
	 * @param v
	 */
	private void divideMap(HashMap<String, Double> map, double v) {
		for (String key : map.keySet()) {
			map.put(key, map.get(key) / v);
		}
	}

	/**
	 * Adds the elements of the map scoreSelected into the map scoreSelectedAll,
	 * summing values that occur in both maps at the same time.
	 * 
	 * @param scoreSelectedAll
	 * @param scoreSelected
	 */
	private void addToMap(HashMap<String, Double> scoreSelectedAll, HashMap<String, Double> scoreSelected) {

		HashSet<String> keys = new HashSet<String>(scoreSelectedAll.keySet());
		keys.addAll(new HashSet<String>(scoreSelected.keySet()));

		for (String key : keys) {
			Double v1 = scoreSelectedAll.get(key);
			if (v1 == null)
				v1 = 0.0;

			Double v2 = scoreSelected.get(key);
			if (v2 == null)
				v2 = 0.0;

			scoreSelectedAll.put(key, v1 + v2);
		}
	}

	/**
	 * Calculates the IMP for the class "className" across all trees in the RF.
	 * If className == null than the IMP is calculated ignoring the class label.
	 * 
	 * @param className
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Double> getConditionScoreForOOBInstances(String className) throws Exception {

		HashMap<String, Double> scoreSelectedAll = new HashMap<String, Double>();

		for (int i = 0; i < this.m_Classifiers.length; i++) { // for each bag
			int nTimesInstanceBag = 0;
			HashMap<String, Double> scoreSelectedTree = new HashMap<String, Double>();
			for (int j = 0; j < this.m_data.size(); j++) { // for each instance

				if (!this.m_inBag[i][j]) {

					String instanceClassName = this.m_data.get(j).classAttribute()
							.value((int) this.m_data.get(j).classValue());

					if (className != null) {
						if (!instanceClassName.equals(className)) {
							continue;
						}
					}

					nTimesInstanceBag++;
					// number of times each feature was used divided the the
					// total number of used features
					HashMap<String, Double> scoreSelected = ((RandomTree) m_Classifiers[i])
							.getConditionScoreForInstance(this.m_data.get(j));

					addToMap(scoreSelectedTree, scoreSelected);

				}
			}

			divideMap(scoreSelectedTree, nTimesInstanceBag);
			addToMap(scoreSelectedAll, scoreSelectedTree);
		}

		divideMap(scoreSelectedAll, this.m_Classifiers.length);

		return scoreSelectedAll;
	}

	/**
	 * Prints the IPM across all trees ignoring the class label.
	 * 
	 * @param writer
	 * @throws Exception
	 */
	public void printOOBConditionScores(PrintWriter writer) throws Exception {
		printOOBConditionScores(writer, null);
	}

	/**
	 * Prints the IPM across all trees for class "className".
	 * 
	 * @param writer
	 * @throws Exception
	 */
	public void printOOBConditionScores(PrintWriter writer, String className) throws Exception {

		if (!m_CalcOutOfBag) {
			throw new Exception("No outofbag information! Run the random tree classifier again, calling "
					+ "setCalcOutOfBag(true)");
		}

		HashMap<String, Double> scoreOOB = getConditionScoreForOOBInstances(className);
		for (String attrName : scoreOOB.keySet()) {
			double score = scoreOOB.get(attrName);
			if (className != null) {
				writer.printf("IPM_SCORE_OOB,%s,%s,%2.4e\n", className, attrName, score);
			} else {
				writer.printf("IPM_SCORE_OOB,all,%s,%2.4e\n", attrName, score);
			}
		}
	}

	/**
	 * Sets the iterations to be tested during the internal cross validation
	 * procedure.
	 * 
	 * @param iterations
	 */
	public void setNumIterationsInternalCV(int[] iterations) {
		this.iterations = iterations;
	}

	/**
	 * Sets the size of the random sampled set to selected the best split to be
	 * tested during the internal cross validation procedure.
	 * 
	 * @param iterations
	 */
	public void setNumFeaturesInternalCV(double[] numFeatsSplit) {
		this.numFeatsSplitMultiArray = numFeatsSplit;

	}

	/**
	 * Sets whether or not to use internal cross-validation.
	 * 
	 * @param iterations
	 */
	public void doInternalCV(boolean b) {
		this.doInternalCV = b;

	}

	/**
	 * Configures the classifier using the best parameters found by the internal
	 * cross-validation procedure.
	 */
	public void setBestInternalCVParameters() {

		int bestIteration = 0;
		int bestFeats = 0;

		int bestCount = 0;
		for (ArrayList<Integer> params : bestParamMap.keySet()) {
			if (bestParamMap.get(params) > bestCount
					|| ((bestParamMap.get(params) == bestCount) && params.get(0) <= bestIteration && params.get(1) <= bestFeats)) {

				bestCount = bestParamMap.get(params);
				bestIteration = params.get(0);
				bestFeats = params.get(1);
			}
		}

		System.out.printf("bestIteration: %d\n", bestIteration);
		System.out.printf("setNumFeatures: %d\n", bestFeats);

		this.setNumIterations(bestIteration);
		this.setNumFeatures(bestFeats);
	}

	/*
	 * Modified buildClassifier method to perform the internal 5 fold cross
	 * validation procedure.
	 */
	public void buildClassifier(Instances instances) throws Exception {

		// this is flag used to indicate (when true) that we are inside a run of
		// the internal cross validation procedure.
		if (this.performingInternalClassification) {
			super.buildClassifier(instances);
			return;
		}

		if (this.doCFS) {
			System.out.printf("CFS_SELECTION,Total attributes:%d\n", instances.numAttributes());
			System.out.flush();
			filter = new AttributeSelection();
			CfsSubsetEval evaluator = new CfsSubsetEval();
			filter.setEvaluator(evaluator);
			final BestFirst search = new BestFirst();
			filter.setSearch(search);
			filter.setInputFormat(instances);
			
			instances = Filter.useFilter(instances, filter);
			System.out.printf("CFS_SELECTION,%d attributes selected\n", instances.numAttributes());
			System.out.flush();
		}
		
		if (doInternalCV) { // if internal cross validation is needed.

			/*
			 * The best ROC value found so far.
			 */
			double bestRoc = 0;

			/*
			 * The best value for the number of iterations found so far.
			 */
			int bestIteration = 0;

			/*
			 * The best value for the number of splits found so far.
			 */
			int bestFeatSplit = 0;

			/*
			 * If true will not performInternalClassification. See the
			 * buildClassifier method for more details.
			 */

			this.performingInternalClassification = true;

			Evaluation eval = new Evaluation(instances);

			// iterates over all combinations of the variables numFeatsSplit and
			// iterations
			for (double featsSplitMulti : this.numFeatsSplitMultiArray) {
				int numberOfFeatures = (int)(featsSplitMulti * Math.sqrt(instances.numAttributes()));
				this.setNumFeatures(numberOfFeatures);
				for (int iteration : this.iterations) {
					this.setNumIterations(iteration);

					eval.crossValidateModel(this, instances, 5, new Random(this.m_Seed));   // the
																							// internal
																							// cross-validation
																							// procedure

					double roc = eval.weightedAreaUnderROC();
					System.out.printf("INTERNALCV,%.4f,%d,%d\n", roc, numberOfFeatures, iteration);
					System.out.flush();

					// update the roc value and the best parameters so far, if
					// needed
					if (roc > bestRoc || (roc == bestRoc && iteration <= bestIteration && numberOfFeatures <= bestFeatSplit)) {
						bestRoc = roc;
						bestIteration = iteration;
						bestFeatSplit = numberOfFeatures;

						System.out.printf("New best params: %.4f %d %d\n", bestRoc, bestIteration, bestFeatSplit);
					}
				}
			}

			// sets the final best parameters that have been found.
			System.out.printf("***  Best params: %.4f %d %d\n", bestRoc, bestIteration, bestFeatSplit);
			this.setNumIterations(bestIteration);
			this.setNumFeatures(bestFeatSplit);

			// updates the count of the best combination of the relevant
			// attributes and induces the final model next.
			ArrayList<Integer> key = new ArrayList<Integer>();
			key.add(bestIteration);
			key.add(bestFeatSplit);

			Integer curBestIteration = bestParamMap.get(key);
			if (curBestIteration == null) {
				curBestIteration = 0;
			}
			bestParamMap.put(key, curBestIteration + 1);
		}

		// train the final model with the optimised parameters.
		super.buildClassifier(instances);
		this.performingInternalClassification = false;

	}
	
	@Override
	public double[] distributionForInstance(Instance instance) throws Exception {
		if (this.doCFS && !this.performingInternalClassification) {
			filter.input(instance);
			instance = filter.output();
		}
		return super.distributionForInstance(instance);
	}

	public void doCFS(boolean b) {
		this.doCFS = b;
	}
	
}
