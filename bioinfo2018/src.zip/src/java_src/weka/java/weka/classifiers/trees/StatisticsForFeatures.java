package weka.classifiers.trees;

import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import weka.core.Instances;


/*
 * Utility class to sort a map by value.
 */
class MapUtil
{
    public static <K, V extends Comparable<? super V>> Map<K, V> 
        sortByValue( Map<K, V> map )
    {
        List<Map.Entry<K, V>> list =
            new LinkedList<Map.Entry<K, V>>( map.entrySet() );
        Collections.sort( list, new Comparator<Map.Entry<K, V>>()
        {
            public int compare( Map.Entry<K, V> o1, Map.Entry<K, V> o2 )
            {
                return (o2.getValue()).compareTo( o1.getValue() );
            }
        } );

        Map<K, V> result = new LinkedHashMap<K, V>();
        for (Map.Entry<K, V> entry : list)
        {
            result.put( entry.getKey(), entry.getValue() );
        }
        return result;
    }
}



/**
 * @author fabio
 * This class will contain the two basis of the PFVP statistics:
 * 
 * 1. The hitsPerClas object (an array of maps).
 * This object uses the class value as an index for the array and the feature name as an index for the map inside
 * the array.
 * The contents of this array represent the number of times the indexed feature (with positive value) was used to correctly classify the
 * indexed class .
 * 
 * 2. coveragePerClas
 * This object is similar to the hitsPerClas object, but it holds the number of times the feature (with positive value)
 * was used to classify the instances using the indexed class value, regardless of the correctness of the classification.
 *
 *	This class also contain two useful objects to calculate other statistics:
 *
 *	idsPerCondition: Records the ids of the instances associated with a given positive condition. This is useful to count
 *	how many "unique" instances were covered
 *
 *	Note that the counts in the previously explained maps can count the same instance several times (because it can be in several
 *	different OOB sets)
 *
 *  treePerCondition: Stores the id of the tree where the positive condition appears on. This is useful to count on how
 *  many different trees the positive conditions appears on.
 *
 */
public class StatisticsForFeatures {

	HashMap<String, Integer>[] hitsPerClas;
	HashMap<String, Integer>[] coveragePerClas;
	HashMap<String, HashSet<Integer>>[] idsPerCondition;
	HashMap<String, HashSet<Integer>>[] treePerCondition;

	@SuppressWarnings("unchecked")
	public StatisticsForFeatures(int nclasses) {
		hitsPerClas = new HashMap[nclasses];
		coveragePerClas = new HashMap[nclasses];
		idsPerCondition = new HashMap[nclasses];
		treePerCondition = new HashMap[nclasses];

		for (int i = 0; i < nclasses; i++) {
			hitsPerClas[i] = new HashMap<String, Integer>();
			coveragePerClas[i] = new HashMap<String, Integer>();
			idsPerCondition[i] = new HashMap<String, HashSet<Integer>>();
			treePerCondition[i] = new HashMap<String, HashSet<Integer>>();
		}
	}

	/**
	 * Adds new statistics to this object.
	 * 
	 * @param numberTimesSelected: the number of times each feature (with positive value) was selected.
	 * @param classCode: The predicted class.
	 * @param isCorrect: Was the instance correctly classified?
	 * @param index: The index of the instance in the dataset.
	 * @param treeIndex: The index of the tree where the condition is coming from.
	 */
	public void update(HashMap<String, Double> numberTimesSelected, double classCode, boolean isCorrect, int index, int treeIndex) {

		for (String condition : numberTimesSelected.keySet()) {				// store the index of the covered instance
			HashSet<Integer> s = idsPerCondition[(int) classCode].get(condition);
			if (s == null) {
				s = new HashSet<Integer>();
			}
			s.add(index);
			idsPerCondition[(int) classCode].put(condition, s);
		}
		
		for (String condition : numberTimesSelected.keySet()) {				// store the index of the tree where the cond. appears
			HashSet<Integer> s = treePerCondition[(int) classCode].get(condition);
			if (s == null) {
				s = new HashSet<Integer>();
			}
			s.add(treeIndex);
			treePerCondition[(int) classCode].put(condition, s);
		}
		
		for (String condition : numberTimesSelected.keySet()) {				// for each selected condition
			Integer c = coveragePerClas[(int) classCode].get(condition);    // increments the condition counter
			if (c == null) {
				c = 0;
			}
			coveragePerClas[(int) classCode].put(condition, c + 1);
		}

		if (isCorrect) { // if the classification was correct, also increment the hitsPerClas map.
			for (String condition : numberTimesSelected.keySet()) {
				Integer c = hitsPerClas[(int) classCode].get(condition);
				if (c == null) {
					c = 0;
				}
				hitsPerClas[(int) classCode].put(condition, c + 1);
			}
		}

	}

	/**
	 * Updates this object using another StatisticsForFeatures. (used to merge the results of the individual
	 * trees of the forest).
	 * @param statisticsForFeatures
	 */
	public void update(StatisticsForFeatures statisticsForFeatures) {
		for (int cla = 0; cla < statisticsForFeatures.hitsPerClas.length; cla++) {
			
			for (String condition : statisticsForFeatures.treePerCondition[cla].keySet()) {
				HashSet<Integer> indexes = statisticsForFeatures.treePerCondition[cla].get(condition);
				HashSet<Integer> auxIndexes = this.treePerCondition[cla].get(condition);
				if (auxIndexes == null) {
					auxIndexes = new HashSet<Integer>();
				}
				auxIndexes.addAll(indexes);
				this.treePerCondition[cla].put(condition, auxIndexes);
			}
			
			
			for (String condition : statisticsForFeatures.idsPerCondition[cla].keySet()) {
				HashSet<Integer> indexes = statisticsForFeatures.idsPerCondition[cla].get(condition);
				HashSet<Integer> auxIndexes = this.idsPerCondition[cla].get(condition);
				if (auxIndexes == null) {
					auxIndexes = new HashSet<Integer>();
				}
				auxIndexes.addAll(indexes);
				this.idsPerCondition[cla].put(condition, auxIndexes);
			}
			
			for (String condition : statisticsForFeatures.hitsPerClas[cla].keySet()) {
				Integer countP = statisticsForFeatures.hitsPerClas[cla].get(condition);
				Integer c = this.hitsPerClas[cla].get(condition);
				if (c == null) {
					c = 0;
				}
				this.hitsPerClas[cla].put(condition, c + countP);
			}
			
			for (String condition : statisticsForFeatures.coveragePerClas[cla].keySet()) {
				Integer countP = statisticsForFeatures.coveragePerClas[cla].get(condition);
				Integer c = this.coveragePerClas[cla].get(condition);
				if (c == null) {
					c = 0;
				}
				this.coveragePerClas[cla].put(condition, c + countP);
			}
		}
	}

	/**
	 * This methods writs the final statistics to "writer".
	 * 
	 * @param writer
	 * @param instances: this will be used to get the class names.
	 * @param oOBClassDistribution: Used to calculate the recall.
	 * @param totalOOBCount: Used to calculate the coverage.
	 */
	public void printStats(PrintWriter writer, Instances instances, HashMap<String, Integer> oOBClassDistribution, double totalOOBCount){
		
		writer.println("PFVP,feature,class,   hits, abs. coverage,     prec,   recall, coverage, unique_inst, n_trees");
		for (int i = 0; i < coveragePerClas.length; i++) {
			String cla = instances.classAttribute().value(i);
			
			for (String key : coveragePerClas[i].keySet()) {
				Integer hits = hitsPerClas[i].get(key);
				if(hits == null){hits = 0;};
				Integer absCov = coveragePerClas[i].get(key);
				double prec = ((double)hits)/absCov;
				double rec =  ((double)hits)/oOBClassDistribution.get(cla);
				double cov =  ((double)absCov)/totalOOBCount;
				
				writer.printf("PFVP,%s, %s, %d, %d, %.4f, %.4f, %.4f, %d, %d\n", key, cla, hits, absCov, prec, rec, cov, 
						idsPerCondition[i].get(key).size(), treePerCondition[i].get(key).size());
			}
		}
	}
	

	/**
	 * This method return the best conditions for a given class, sorted by precision (first one is the best).
	 * The best conditions are defined as the ones with precision greater than 0.5
	 * @param clas
	 * @return
	 */
	public HashSet<String> getTopFeatures(int clas) {
		
		HashMap<String, Integer> featureMap = new HashMap<String, Integer>();
		for(String featureName : hitsPerClas[clas].keySet()){
			Integer hits = hitsPerClas[clas].get(featureName);
			Integer cov = hitsPerClas[clas].get(featureName);
			
			if(hits/cov >= 0.5){
				featureMap.put(featureName, cov);
			}
		}
		
		HashMap<String, Integer> sortedFeatures = (HashMap<String, Integer>) MapUtil.sortByValue(featureMap);
		HashSet<String> ret = new HashSet<String>();
		for(String featureName: sortedFeatures.keySet()){
			ret.add(featureName);
		}
		
		return ret;
	}

}
