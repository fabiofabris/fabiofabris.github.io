package weka.classifiers.trees;


/**
 * @author Fabio Fabris
 * This class encodes a Condition, that is, a feature name, a feature value and an operator (if the instance is numeric) 
 *
 */
public class Condition {

	// auto-generated hash method:
	@Override 
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((attrName == null) ? 0 : attrName.hashCode());
		result = prime * result + ((attrValue == null) ? 0 : attrValue.hashCode());
		result = prime * result + (isNominal ? 1231 : 1237);
		result = prime * result + ((operator == null) ? 0 : operator.hashCode());
		return result;
	}

	// auto-generated equals method:
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Condition other = (Condition) obj;
		if (attrName == null) {
			if (other.attrName != null)
				return false;
		} else if (!attrName.equals(other.attrName))
			return false;
		if (attrValue == null) {
			if (other.attrValue != null)
				return false;
		} else if (!attrValue.equals(other.attrValue))
			return false;
		if (isNominal != other.isNominal)
			return false;
		if (operator == null) {
			if (other.operator != null)
				return false;
		} else if (!operator.equals(other.operator))
			return false;
		return true;
	}

	private String attrValue;  	// the attribute value
	private String attrName;	// the attribute name
	private String operator;	// the operator
	private boolean isNominal;	// a flag indicating if the feature is nominal. If it is, "operator" is always "=".
	
	
	
	/**
	 * Gets the value of the attribute.
	 * @return
	 */
	public String getAttrValue() {
		return attrValue;
	}

	/**
	 * Gets the name of the attribute. 
	 * 
	 * @return
	 */
	public String getAttrName() {
		return attrName;
	}

	
	/**
	 * Gets the operator.
	 * @return
	 */
	public String getOperator() {
		return operator;
	}

	/**
	 * Gets whether or not the condition involves a nominal feature. If that is the case the operator is always "="
	 * @return
	 */
	public boolean isNominal() {
		return isNominal;
	}

	/**
	 * Constructor for nominal attributes.
	 * @param attrName
	 * @param attrValue
	 * @param attrIndex
	 */
	public Condition(String attrName, String attrValue, int attrIndex) {
		this.attrName = attrName;
		this.attrValue = attrValue;
		this.operator = "=";
		this.isNominal = true;
	}

	/**
	 * Constructor for numerical attributes.
	 * @param attrName
	 * @param attrValue
	 * @param operator
	 * @param attrIndex
	 */
	public Condition(String attrName, String attrValue, String operator, int attrIndex) {
		this.attrName = attrName;
		this.attrValue = attrValue;
		this.operator = operator;
		this.isNominal = false;
	}

	public String toString() {
		return this.attrName + " " + this.operator + " " + this.attrValue;
	}


}