package weka.classifiers.trees;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import weka.core.Instances;

/**
 * This class holds the summed distributions of the class values across all
 * out-bags (oOBClassDistribution), the summations of the the sizes of the OOB
 * sets (totalOOBCount) and the StatisticsForFeatures objects, which contain the
 * number of times each "positive feature" was used in the tree to classify a
 * given classes (the coverage), the number of times the classification was
 * correct (the number of hits), the id's of the instances covered by each positive condition
 * and the id's of the trees that the condition appears on.
 * 
 * @author Fabio Fabris
 * 
 */
public class PositiveValueStats {

	private double totalOOBCount; 							// added out bags sizes
	private HashMap<String, Integer> oOBClassDistribution; 	// added OOB
															// distributions
	StatisticsForFeatures stats; 							// the positive feature statistics

	
	/**
	 * The constructor for the statistics. Should be called one per Random Forest.
	 * 
	 * @param totalOOBCount: the sum of the sizes of all OOB sets.
	 * @param oOBClassDistribution: The summed class frequencies across all OOB sets.
	 * @param nClasses: the number of classes in the dataset used to train the forest.
	 */
	public PositiveValueStats(double totalOOBCount, HashMap<String, Integer> oOBClassDistribution, int nClasses) {
		this.totalOOBCount = totalOOBCount;
		this.oOBClassDistribution = oOBClassDistribution;
		stats = new StatisticsForFeatures(nClasses);
	}

	/**
	 * Should be called once per RT to combine the statistics for a RT with the overall statistics for the whole RF.
	 * 
	 * @param statisticsForFeatures: The statistics for a RT.
	 */
	public void update(StatisticsForFeatures statisticsForFeatures) {
		stats.update(statisticsForFeatures);
	}

	/**
	 * Just prints the calculated statistics.
	 * @param writer
	 * @param intances
	 */
	public void printStats(PrintWriter writer, Instances intances) {
		writer.println("PFVP_TOTAL,totalOOBCount: " + totalOOBCount);
		writer.println("PFVP_TOTAL,oOBClassDistribution: " + oOBClassDistribution);
		stats.printStats(writer, intances, oOBClassDistribution, totalOOBCount);
	}

	/**
	 * Gets a map indexed by the class name and values representing the a set of the most important features (positive conditions)
	 * for that class name.
	 * 
	 * @param instances
	 * @return
	 */
	public HashMap<String, HashSet<String>> getTopFeatures(Instances instances) {

		HashMap<String, HashSet<String>> topFeatures = new HashMap<String, HashSet<String>>();
		for (String clas : oOBClassDistribution.keySet()) {
			int clasIndx = instances.classAttribute().indexOfValue(clas);
			topFeatures.put(clas, stats.getTopFeatures(clasIndx));
		}

		return topFeatures;
	}

}
